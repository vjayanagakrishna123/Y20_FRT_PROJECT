# KLTRVELS-BOT ✈️🧳:

This project is about the website which is made for the purpose of best place to vist for users


# Azure services used in this project

1)QnA maker 2)Static webapps 3)Azure Bot Service

For creating Question and Answer pair, I have used QnAMaker. I integreted QnAMAker with Web App bot. Then for hosting I have used Static Web App Service. Azure Static Web Apps is a service that automatically builds and deploys full stack web apps to Azure from a code repository.

# Azure Static Web Apps: 

Following are some key features of Azure Static Web Apps that made me choose this service:

1.Web hosting for static content like HTML, CSS, JavaScript, and images.

2.Integrated API support provided by Azure Functions with the option to link an existing Azure Functions app using a standard account.

3.First-class GitHub and Azure DevOps integration where repository changes trigger builds and deployments.

4.Globally distributed static content, putting content closer to your users.

5.Free SSL certificates, which are automatically renewed.

6.Custom domains to provide branded customizations to your app.

Project Link:https://yellow-bush-0868bd810.1.azurestaticapps.net

# Sample images of the project :

![1](https://user-images.githubusercontent.com/98799260/169684343-cb50b244-f446-4f08-9111-698b82ff1f4a.png)
![2](https://user-images.githubusercontent.com/98799260/169684344-fad28426-0f7f-44f2-8020-5a1e10f0de47.png)
![3](https://user-images.githubusercontent.com/98799260/169684345-652f4335-2fb7-441b-a0e9-a73f27966785.png)
![4](https://user-images.githubusercontent.com/98799260/169684347-d341c7e3-6b0b-424e-b155-680bd2970d9b.png)
![5](https://user-images.githubusercontent.com/98799260/169684350-58ff5e8c-80bb-4ca8-849a-e7bd8b2eb333.png)
